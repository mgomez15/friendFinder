var friends = [{
        "name": "Donna",
        "photo": "https://media.licdn.com/mpr/mpr/shrinknp_400_400/p/6/005/064/1bd/3435aa3.jpg",
        "difference": [
            5,
            1,
            4,
            4,
            5,
            1,
            2,
            5,
            4,
            1
        ]
    },
    {
        "name": "Jackie",
        "photo": "https://avatars0.githubusercontent.com/u/1561825?v=3&s=460",
        "scores": [
            5,
            1,
            4,
            4,
            5,
            1,
            2,
            5,
            4,
            1
        ]
    },
    {
        "name": "Kelso",
        "photo": "https://avatars0.githubusercontent.com/u/1561825?v=3&s=460",
        "scores": [
            5,
            1,
            4,
            4,
            5,
            1,
            2,
            5,
            4,
            1
        ]
    },
    {
        "name": "Eric",
        "photo": "https://avatars0.githubusercontent.com/u/1561825?v=3&s=460",
        "scores": [
            5,
            1,
            4,
            4,
            5,
            1,
            2,
            5,
            4,
            1
        ]
    },
    {
        "name": "Fez",
        "photo": "https://avatars0.githubusercontent.com/u/1561825?v=3&s=460",
        "scores": [
            5,
            1,
            4,
            4,
            5,
            1,
            2,
            5,
            4,
            1
        ]
    },
    {
        "name": "Hyde",
        "photo": "https://avatars0.githubusercontent.com/u/1561825?v=3&s=460",
        "scores": [
            5,
            1,
            4,
            4,
            5,
            1,
            2,
            5,
            4,
            1
        ]
    }
];